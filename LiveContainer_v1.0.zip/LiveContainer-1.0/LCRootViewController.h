#import <UIKit/UIKit.h>

@interface LCRootViewController : UITableViewController
@property(nonatomic) NSString* acError;
@end
